def calculate_average_help_occurrences(output):
    lines = output.split('\n')
    help_count = 0
    fix_count = 0

    for line in lines:
        if "and needs help" in line:
            help_count += 1
        elif "The third elf is informing others and Santa." in line:
            fix_count += 1

    # Calculate average
    if fix_count > 0:
        average_help_occurrences = help_count / fix_count
        return average_help_occurrences
    else:
        return 0  # Avoid division by zero

# Example usage
output_example = """
 
Starting with 9 reindeer and 12 elves
Reindeer 0 has gone on holiday
Reindeer 1 has gone on holiday
Reindeer 2 has gone on holiday
Reindeer 3 has gone on holiday
Reindeer 4 has gone on holiday
Reindeer 5 has gone on holiday
Reindeer 6 has gone on holiday
Reindeer 7 has gone on holiday
Elf 0 has started building presents
Elf 1 has started building presents
Reindeer 8 has gone on holiday
Elf 2 has started building presents
Elf 3 has started building presents
Elf 4 has started building presents
Elf 5 has started building presents
Elf 7 has started building presents
Elf 8 has started building presents
Elf 6 has started building presents
Elf 9 has started building presents
Elf 10 has started building presents
All processes started
Elf 11 has started building presents
Elf 1 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 1 has started building presents
Elf 2 has started building presents
Elf 3 has started building presents
Santa is sorting problems
Elf 7 has encountered a problem and needs help
Elf 8 has encountered a problem and needs help
Elf 6 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 7 has started building presents
Elf 6 has started building presents
Elf 11 has encountered a problem and needs help
Elf 8 has started building presents
Elf 0 has encountered a problem and needs help
Elf 4 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 2 has encountered a problem and needs help
Elf 5 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
Elf 9 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
Elf 0 has started building presents
Elf 4 has started building presents
Elf 2 has started building presents
Elf 11 has started building presents
Elf 5 has started building presents
Elf 3 has started building presents
Elf 9 has started building presents
Elf 7 has started building presents
Elf 10 has started building presents
Elf 1 has encountered a problem and needs help
Elf 6 has encountered a problem and needs help
Elf 8 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 1 has started building presents
Elf 6 has started building presents
Elf 8 has started building presents
Elf 2 has encountered a problem and needs help
Elf 11 has encountered a problem and needs help
Elf 5 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 2 has started building presents
Elf 11 has started building presents
Santa is sorting problems
Elf 9 has encountered a problem and needs help
Elf 5 has started building presents
Elf 1 has encountered a problem and needs help
Elf 0 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 9 has started building presents
Elf 1 has started building presents
Elf 4 has encountered a problem and needs help
Elf 0 has started building presents
Elf 3 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
Elf 11 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 7 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
Elf 5 has encountered a problem and needs help
Santa is sorting problems
Elf 4 has started building presents
Elf 3 has started building presents
Elf 11 has started building presents
Elf 2 has started building presents
Elf 7 has started building presents
Elf 10 has started building presents
Elf 6 has encountered a problem and needs help
Elf 8 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 5 has started building presents
Elf 8 has started building presents
Elf 6 has started building presents
Elf 11 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 11 has started building presents
Elf 7 has started building presents
Elf 10 has started building presents
Elf 5 has encountered a problem and needs help
Elf 9 has encountered a problem and needs help
Elf 1 has encountered a problem and needs help
Elf 8 has encountered a problem and needs help
Elf 0 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 6 has encountered a problem and needs help
Santa is sorting problems
Elf 5 has started building presents
Elf 1 has started building presents
Elf 8 has started building presents
Elf 0 has started building presents
Elf 9 has started building presents
Elf 6 has started building presents
Elf 4 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 3 has started building presents
Elf 4 has started building presents
Elf 2 has started building presents
Elf 1 has encountered a problem and needs help
Elf 8 has encountered a problem and needs help
Elf 9 has encountered a problem and needs help
Elf 0 has encountered a problem and needs help
Elf 6 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 8 has started building presents
Elf 1 has started building presents
Elf 3 has encountered a problem and needs help
Elf 0 has started building presents
Elf 4 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
Elf 11 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
Elf 6 has started building presents
Elf 9 has started building presents
Elf 3 has started building presents
Elf 2 has started building presents
Elf 4 has started building presents
The third elf is informing others and Santa.
Elf 7 has started building presents
Santa is sorting problems
Elf 11 has started building presents
Elf 10 has started building presents
Elf 5 has encountered a problem and needs help
Elf 8 has encountered a problem and needs help
Elf 6 has encountered a problem and needs help
Elf 9 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 2 has encountered a problem and needs help
Santa is sorting problems
Elf 5 has started building presents
Elf 8 has started building presents
Elf 6 has started building presents
Elf 9 has started building presents
Elf 2 has started building presents
Elf 7 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
Elf 1 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 7 has started building presents
Santa is sorting problems
Elf 1 has started building presents
Elf 10 has started building presents
Elf 0 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
Elf 4 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 0 has started building presents
Elf 3 has started building presents
Elf 4 has started building presents
Elf 8 has encountered a problem and needs help
Elf 6 has encountered a problem and needs help
Elf 9 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 8 has started building presents
Elf 6 has started building presents
Elf 11 has encountered a problem and needs help
Elf 9 has started building presents
Elf 1 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 11 has started building presents
Elf 1 has started building presents
Elf 10 has started building presents
Elf 5 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 5 has started building presents
Elf 2 has started building presents
Elf 7 has started building presents
Santa is sorting problems
Elf 11 has encountered a problem and needs help
Elf 0 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
Elf 4 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 8 has encountered a problem and needs help
Elf 6 has encountered a problem and needs help
Elf 9 has encountered a problem and needs help
Elf 11 has started building presents
Elf 0 has started building presents
Elf 4 has started building presents
Elf 8 has started building presents
Elf 3 has started building presents
Elf 5 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 1 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
Santa is sorting problems
Elf 6 has started building presents
Elf 5 has started building presents
Elf 9 has started building presents
Elf 7 has started building presents
Elf 1 has started building presents
Elf 10 has started building presents
Elf 11 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 11 has started building presents
Santa is sorting problems
Elf 3 has started building presents
Elf 2 has started building presents
Elf 6 has encountered a problem and needs help
Elf 9 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 6 has started building presents
Elf 9 has started building presents
Elf 0 has encountered a problem and needs help
Elf 7 has started building presents
Elf 10 has started building presents
Elf 4 has encountered a problem and needs help
Elf 0 has started building presents
Elf 8 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 4 has started building presents
Elf 8 has started building presents
Elf 2 has started building presents
Elf 5 has encountered a problem and needs help
Elf 1 has encountered a problem and needs help
Elf 9 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
Elf 0 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 1 has started building presents
Elf 5 has started building presents
Elf 0 has started building presents
Elf 10 has started building presents
Elf 7 has started building presents
Elf 9 has started building presents
Elf 11 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
Elf 4 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 11 has started building presents
Santa is sorting problems
Elf 3 has started building presents
Elf 4 has started building presents
Elf 6 has encountered a problem and needs help
Elf 2 has started building presents
Elf 1 has encountered a problem and needs help
Elf 5 has encountered a problem and needs help
Elf 0 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
Elf 9 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 6 has started building presents
Elf 5 has started building presents
Elf 1 has started building presents
Elf 0 has started building presents
Elf 9 has started building presents
Elf 10 has started building presents
Elf 8 has encountered a problem and needs help
Elf 11 has encountered a problem and needs help
Elf 4 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 8 has started building presents
Elf 11 has started building presents
Elf 4 has started building presents
Elf 2 has started building presents
Elf 7 has encountered a problem and needs help
Elf 6 has encountered a problem and needs help
Elf 9 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 7 has started building presents
Elf 6 has started building presents
Elf 9 has started building presents
Elf 10 has started building presents
Elf 3 has encountered a problem and needs help
Elf 8 has encountered a problem and needs help
Elf 1 has encountered a problem and needs help
Elf 5 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 0 has encountered a problem and needs help
Santa is sorting problems
Elf 3 has started building presents
Elf 8 has started building presents
Elf 5 has started building presents
Elf 1 has started building presents
Elf 6 has encountered a problem and needs help
Elf 0 has started building presents
Elf 11 has encountered a problem and needs help
Elf 4 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 11 has started building presents
Elf 6 has started building presents
Elf 4 has started building presents
Elf 2 has started building presents
Elf 8 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
Elf 9 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
Elf 1 has encountered a problem and needs help
Elf 0 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 8 has started building presents
Elf 3 has started building presents
Elf 9 has started building presents
Elf 1 has started building presents
Elf 7 has started building presents
Elf 0 has started building presents
Elf 10 has started building presents
Elf 5 has encountered a problem and needs help
Elf 8 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
Elf 9 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 10 has encountered a problem and needs help
Santa is sorting problems
Elf 5 has started building presents
Elf 8 has started building presents
Elf 9 has started building presents
Elf 7 has started building presents
Elf 3 has started building presents
Elf 10 has started building presents
Reindeer 2's holiday is over
Reindeer 6's holiday is over
Elf 6 has encountered a problem and needs help
Elf 11 has encountered a problem and needs help
Elf 4 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 11 has started building presents
Elf 6 has started building presents
Elf 4 has started building presents
Elf 2 has started building presents
Elf 1 has encountered a problem and needs help
Elf 0 has encountered a problem and needs help
Elf 8 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 0 has started building presents
Elf 1 has started building presents
Elf 8 has started building presents
Reindeer 4's holiday is over
Reindeer 3's holiday is over
Elf 4 has encountered a problem and needs help
Elf 5 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
Elf 9 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 0 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
Santa is sorting problems
Elf 4 has started building presents
Elf 5 has started building presents
Elf 3 has started building presents
Elf 0 has started building presents
Elf 10 has started building presents
Elf 7 has started building presents
Elf 9 has started building presents
Elf 11 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
Elf 6 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 2 has started building presents
Elf 11 has started building presents
Elf 6 has started building presents
Elf 1 has encountered a problem and needs help
Elf 8 has encountered a problem and needs help
Elf 5 has encountered a problem and needs help
Elf 4 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 0 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
Santa is sorting problems
Elf 1 has started building presents
Elf 5 has started building presents
Elf 4 has started building presents
Elf 0 has started building presents
Elf 8 has started building presents
Elf 10 has started building presents
Elf 2 has encountered a problem and needs help
Elf 6 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 9 has encountered a problem and needs help
Santa is sorting problems
Elf 2 has started building presents
Elf 3 has started building presents
Elf 6 has started building presents
Elf 5 has encountered a problem and needs help
Elf 0 has encountered a problem and needs help
Elf 7 has started building presents
The third elf is informing others and Santa.
Santa is sorting problems
Elf 5 has started building presents
Elf 9 has started building presents
Elf 0 has started building presents
Elf 10 has encountered a problem and needs help
Elf 11 has encountered a problem and needs help
Elf 1 has encountered a problem and needs help
Elf 4 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 8 has encountered a problem and needs help
Elf 5 has encountered a problem and needs help
Elf 10 has started building presents
Elf 11 has started building presents
Elf 5 has started building presents
Elf 7 has started building presents
Elf 4 has started building presents
Elf 8 has started building presents
Elf 1 has started building presents
Elf 6 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 6 has started building presents
Elf 2 has started building presents
Elf 3 has started building presents
Elf 9 has encountered a problem and needs help
Elf 0 has encountered a problem and needs help
Elf 5 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 9 has started building presents
Elf 5 has started building presents
Elf 11 has encountered a problem and needs help
Elf 4 has encountered a problem and needs help
Elf 0 has started building presents
Reindeer 1's holiday is over
Reindeer 7's holiday is over
Elf 6 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 11 has started building presents
Elf 4 has started building presents
Elf 6 has started building presents
Elf 10 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
Elf 8 has encountered a problem and needs help
Elf 1 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 10 has started building presents
Elf 7 has started building presents
Elf 8 has started building presents
Elf 1 has started building presents
Reindeer 0's holiday is over
Reindeer 8's holiday is over
Elf 2 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
Elf 4 has encountered a problem and needs help
Elf 6 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 3 has started building presents
Elf 6 has started building presents
Elf 9 has encountered a problem and needs help
Elf 5 has encountered a problem and needs help
Elf 2 has started building presents
Elf 4 has started building presents
Elf 0 has encountered a problem and needs help
Elf 8 has encountered a problem and needs help
Elf 1 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 9 has started building presents
Elf 5 has started building presents
Elf 0 has started building presents
Elf 8 has started building presents
Elf 1 has started building presents
Reindeer 5's holiday is over
The last reindeer is informing others and Santa.
Santa is delivering presents with the reindeers
Reindeer 2 has gone on holiday
Reindeer 6 has gone on holiday
Reindeer 4 has gone on holiday
Reindeer 3 has gone on holiday
Reindeer 0 has gone on holiday
Reindeer 8 has gone on holiday
Reindeer 7 has gone on holiday
Reindeer 5 has gone on holiday
Reindeer 1 has gone on holiday
Elf 11 has encountered a problem and needs help
Elf 4 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 11 has started building presents
Elf 4 has started building presents
Elf 7 has started building presents
Elf 10 has started building presents
Elf 9 has encountered a problem and needs help
Elf 8 has encountered a problem and needs help
Elf 6 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 3 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
Santa is sorting problems
Elf 9 has started building presents
Elf 8 has started building presents
Elf 6 has started building presents
Elf 3 has started building presents
Elf 2 has started building presents
Elf 11 has encountered a problem and needs help
Elf 4 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 4 has started building presents
Elf 11 has started building presents
Elf 5 has encountered a problem and needs help
Elf 10 has started building presents
Elf 0 has encountered a problem and needs help
Elf 1 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 5 has started building presents
Elf 0 has started building presents
Santa is sorting problems
Elf 1 has started building presents
Elf 6 has encountered a problem and needs help
Elf 7 has encountered a problem and needs help
Elf 0 has encountered a problem and needs help
Elf 1 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 7 has started building presents
Elf 1 has started building presents
Elf 0 has started building presents
Elf 6 has started building presents
Santa is sorting problems
Elf 9 has encountered a problem and needs help
Elf 8 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
Elf 2 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 9 has started building presents
Elf 2 has started building presents
Elf 3 has started building presents
Elf 8 has started building presents
Elf 4 has encountered a problem and needs help
Elf 10 has encountered a problem and needs help
Elf 11 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 10 has started building presents
Elf 11 has started building presents
Elf 4 has started building presents
Elf 5 has encountered a problem and needs help
Elf 6 has encountered a problem and needs help
Elf 9 has encountered a problem and needs help
Elf 3 has encountered a problem and needs help
The third elf is informing others and Santa.
Santa is sorting problems
Elf 5 has started building presents
Elf 6 has started building presents
Elf 9 has started building presents
Elf 3 has started building presents
Elf 10 has encountered a problem and needs help
Elf 11 has encountered a problem and needs help
Elf 4 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 10 has started building presents
Santa is sorting problems
Elf 11 has started building presents
Elf 4 has started building presents
Elf 7 has encountered a problem and needs help
Elf 1 has encountered a problem and needs help
Elf 0 has encountered a problem and needs help
The third elf is informing others and Santa.
Elf 7 has started building presents
Santa is sorting problems
Elf 1 has started building presents
Elf 0 has started building presents
"""

average_occurrences = calculate_average_help_occurrences(output_example)
print(f"Average occurrences of 'and needs help' before 'Santa is fixing the problem for the 3 elves': {average_occurrences}")
